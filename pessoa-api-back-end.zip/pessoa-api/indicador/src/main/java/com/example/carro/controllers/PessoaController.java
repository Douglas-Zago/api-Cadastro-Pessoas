package com.example.carro.controllers;

import com.example.carro.repository.PessoaRepository;
import com.example.carro.entity.Pessoa;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin("*")
@RestController //diz que a classe é controladora de requisiçoes REST(CRUD)
@RequestMapping("/pessoas")
@RequiredArgsConstructor
public class PessoaController {

    private final PessoaRepository repository; //FINAL SERVE PARA DIZER QUE E IMUTAVEL E NAO SERA MUDADO

    @GetMapping
    @ResponseBody //converter java para json enviando para o html
    public List<Pessoa> buscarTodosCarros() {
        return repository.findAll();
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerPorId(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        }
    }

    @ResponseBody //para ser responsivo a  saida de dados
    @PostMapping//para ser responsivo a  entrada de dados
    @ResponseStatus(HttpStatus.CREATED)
    public Pessoa cadastrarNovo(@RequestBody Pessoa novaPessoa) {
        novaPessoa.setId(null);
        return repository.save(novaPessoa);
    }

    @GetMapping("/{id}") // OPTIONAL SERVE PARA SER UM JEITO MAIS PRO DE VERIFICAR SE ESTA VAZIO OU TEM ALGO
    public ResponseEntity<Pessoa> buscarPessoaPorId(@PathVariable(name = "id") Long codigo) {
        Optional<Pessoa> optionalBD = repository.findById(codigo); //BUSCA POR ID O QUE ESTA VINDO DO BANCO DE DADOS USANDO OPTIONAL
        if (optionalBD.isEmpty()) { //VERIFICANDO SE ESTA VAZIO O CARRO QUE REPRESENTA O ID
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); //RETORNANDO QUE FOI ENCONTRADO MAS NAO TEM NADA
        }
        return new ResponseEntity<>(optionalBD.get(), HttpStatus.OK); //RETORNANDO OK QUE ACHOU E TEM INFORMAÇOES
    }

    //http://localhost:8080/carros/1
    @PutMapping("/{id}") //vai ser encontrado pelo id
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Pessoa> atualizarRegistro(@PathVariable Long id, //garante que sempre pegue o id da requisiçao e nao do body
                                                    @RequestBody Pessoa pessoaFront) { //CARRO QUE ESTA VINDO DO FRONT

        if (repository.existsById(id)) {//se nao tiver nada ele nao vai atualizar nada
            pessoaFront.setId(id); //atualiza e garante que vai ser atualizado por receber um parametro ID
            Pessoa pessoaEditado = repository.save(pessoaFront);
            return new ResponseEntity<>(pessoaEditado, HttpStatus.OK); //RETORNANDO OK QUE ACHOU E TEM INFORMAÇOES
        }

        return new ResponseEntity<>(HttpStatus.NO_CONTENT); //RETORNANDO QUE FOI ENCONTRADO MAS NAO TEM NADA
    }
}


