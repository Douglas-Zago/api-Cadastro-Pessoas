package com.example.carro.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter //Vai gerar todos os metodo getters dos atributos
@Setter //Vai gerar todos os metodo setters dos atributos
@AllArgsConstructor // vai criar um construtor com todos os atributos
@NoArgsConstructor // vai criar um construtor default

@Table(name = "db-pessoa")
@Entity
public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(nullable = false, length = 150)
    private String email;

    @Column(nullable = false, length = 150)
    private String telefone;

    @Column(length = 150)
    private String endereco;

    @Column
    private boolean ativo;
}
