

// Função para buscar um registro pelo id ao abrir a pagina
function buscarRegistroPorId() {

    const parametros = new URLSearchParams(window.location.search); //pegando todos os parametros da url

    // Recupera os valores dos parâmetros usando get()
    const idPessoa = parametros.get('id');

    const url = `http://localhost:8080/pessoas/${idPessoa}`

    fetch(url) //como padrao ja é get //nao precisa definir o metodo
        .then(response => response.json()) //entao me devolve um json
        .then(pessoa => { 
            // Preenche o formulário com os dados recebidos
            document.querySelector('#id').value = pessoa.id; //atribuindo o valor de pessoa.id para #id
            document.querySelector('#nome').value = pessoa.nome;
            document.querySelector('#email').value = pessoa.email;
            document.querySelector('#telefone').value = pessoa.telefone;
            document.querySelector('#endereco').value = pessoa.endereco;
            document.querySelector('#ativo').checked = pessoa.ativo;
            
            
        })
        .catch(error => {
            console.error('Erro:', error);
        });
}


function bodyJsonPessoa() {

    const id = document.querySelector('#id').value;
    const nome = document.querySelector('#nome').value;
    const email = document.querySelector('#email').value;
    const telefone = document.querySelector('#telefone').value;
    const endereco = document.querySelector('#endereco').value;
    const ativo = document.querySelector('#ativo').checked;

    const pessoa = {
        id : id,
        nome: nome,
        email: email,
        telefone: telefone,
        endereco: endereco,
        ativo: ativo
    };

    // Converte o objeto em JSON
    const json = JSON.stringify(pessoa);

    return json;
}

function redirecionarListagem(){
    window.location.href = './index.html';
}

// Obtém uma referência ao formulário
const form = document.querySelector('#formulario');

// Define o manipulador de evento para o envio do formulário
form.addEventListener('submit', function (e) {
    e.preventDefault(); // Impede o envio padrão do formulário

    // criar um json na estrutura para enviar ao backend.
    const bodyJson = bodyJsonPessoa();
    const idPessoa = document.querySelector("#id").value;
    const url = `http://localhost:8080/pessoas/${idPessoa}`;

    // Faz a requisição POST para o endpoint do Spring usando o método fetch
    fetch(url, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: bodyJson
    })
        .then(function (response) {
            // Manipula a resposta do servidor em caso de sucesso
            if (response.ok) {   //Vendo se a resposta deu ok
                alert("Dados registrados com sucesso");
                redirecionarListagem();
            } else {
                alert("Erro ao enviar o formulário");
            }
        })
        .catch(function (error) {
            // Manipula erros em caso de falha na requisição
            console.error(error);
        });

});


buscarRegistroPorId();




