// Função para preencher a tabela com os registros
function preencherTabela(registros) {
    const corpoTabela = document.querySelector('#tabelaRegistros tbody'); // pegando o id da tabela(table) e o tboby(filho da table), ou adicionar um id ao tboby

    //usando forEach para porcorrer a lista
    registros.forEach(registro => { //para cada elemento chama função
        const row = corpoTabela.insertRow();
        row.dataset.id = registro.id; 

        const idCell = row.insertCell();
        idCell.textContent = registro.id;

        const nomeCell = row.insertCell();
        nomeCell.textContent = registro.nome;

        const emailCell = row.insertCell();
        emailCell.textContent = registro.email;

        const telefoneCell = row.insertCell();
        telefoneCell.textContent = registro.telefone;

        const enderecoCell = row.insertCell();
        enderecoCell.textContent = registro.endereco;

        const ativoCell = row.insertCell();
        ativoCell.textContent = registro.ativo ? "Sim" :  "Não";

        const acoesCell = row.insertCell(); //criando a celula de açoes
        acoesCell.classList.add('text-center'); //centralizando as acçoes utilizando o classList

        const editButton = document.createElement('button'); //criando um elemento button
        editButton.textContent = 'Editar'; //texto do botão
        editButton.classList.add('btn'); //adicionando styles dos botões, estilizando
        editButton.classList.add('btn-outline-dark');
        editButton.classList.add('me-2');
        editButton.addEventListener('click', () => redirecionarEdicao(registro.id)); //evendo que ao clicar chama uma função e passa o id do elemento
        acoesCell.appendChild(editButton);
        
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Excluir';
        deleteButton.classList.add('btn');
        deleteButton.classList.add('btn-outline-danger');
        deleteButton.addEventListener('click', () => excluirRegistro(registro.id)); // ao clicar chamar a função exluirRegistro
        acoesCell.appendChild(deleteButton);

    });
}



// Função para redirecionar para edição
function redirecionarEdicao(id) {
    window.location.href = './editar.html?id='+id;
}


// Função para excluir um registro
function excluirRegistro(id) {

    // Exibe a caixa de diálogo de confirmação
    const confirmacao = confirm("Tem certeza que deseja remover este registro?"); 

    if (confirmacao) {

        const url = `http://localhost:8080/pessoas/${id}`

            fetch(url, {
                method: 'DELETE'
            })
            .then(response => {
                if (response.ok) {
                    // Registro excluído com sucesso
                    console.log('Registro excluído com sucesso');
                    alert('Registro excluído com sucesso');
                    // Remover a linha da tabela correspondente ao registro excluído
                    const tabela = document.querySelector('#tabelaRegistros');
                    const linha = tabela.querySelector(`tr[data-id="${id}"]`);
                    linha.remove();
                } else {
                    // Ocorreu um erro ao excluir o registro
                    console.error('Erro ao excluir o registro');
                }
            })
            .catch(error => {
                console.error('Erro:', error);
            });
    }
}




function buscarRegistros() {
    // Faz a requisição GET para obter os registros
    const url = `http://localhost:8080/pessoas`
    fetch(url)
        .then(response => response.json())
        .then(pessoas => {
            preencherTabela(pessoas);
        })
        .catch(error => {
            console.error('Erro:', error);
        });
}



buscarRegistros();